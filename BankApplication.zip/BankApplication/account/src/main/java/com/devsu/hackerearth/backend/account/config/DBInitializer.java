package com.devsu.hackerearth.backend.account.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

@Configuration
public class DBInitializer implements CommandLineRunner {

    @Autowired
    private DataSource dataSource;

    private final String BACKUP_PATH = "data/h2_backup_clientes.sql";

    @Override
    public void run(String... args) throws Exception {
        if (Files.exists(Paths.get(BACKUP_PATH))) {
            try (Connection conn = dataSource.getConnection();
                    Statement stmt = conn.createStatement()) {
                stmt.execute("DROP ALL OBJECTS");
                stmt.execute("RUNSCRIPT FROM '" + BACKUP_PATH + "'");
                System.out.println("H2 restaurado desde backup: " + BACKUP_PATH);
            } catch (SQLException e) {
                e.printStackTrace();
                System.err.println("Error al restaurar H2");
            }
        }
    }
}
