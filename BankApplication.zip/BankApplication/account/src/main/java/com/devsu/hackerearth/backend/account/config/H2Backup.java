package com.devsu.hackerearth.backend.account.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PreDestroy;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.nio.file.Files;
import java.nio.file.Paths;

@Component
public class H2Backup {

    @Autowired
    private DataSource dataSource;

    private final String BACKUP_PATH = "data/h2_backup_clientes.sql";

    @PreDestroy
    public void exportH2() {
        try {
            Files.createDirectories(Paths.get("data"));

            try (Connection conn = dataSource.getConnection();
                 Statement stmt = conn.createStatement()) {

                stmt.execute("SCRIPT TO '" + BACKUP_PATH + "'");
                System.out.println("Backup de H2 exportado correctamente a " + BACKUP_PATH);
            }
        } catch (SQLException | java.io.IOException e) {
            e.printStackTrace();
            System.err.println("Error al exportar H2");
        }
    }
}