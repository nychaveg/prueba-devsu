package com.devsu.hackerearth.backend.account.controller;

import java.util.List;

import com.devsu.hackerearth.backend.account.model.dto.ClientRefDto;
import com.devsu.hackerearth.backend.account.service.ClientRefService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/client-ref")
public class ClienteRefController {

    private final ClientRefService clientRefService;

    public ClienteRefController(ClientRefService clientRefService) {
        this.clientRefService = clientRefService;
    }

    @GetMapping
    public List<ClientRefDto> getAll() {
        return clientRefService.getAll();
    }

    @PostMapping
    public ResponseEntity<Void> create(@RequestBody ClientRefDto dto) {
        clientRefService.create(dto);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

}