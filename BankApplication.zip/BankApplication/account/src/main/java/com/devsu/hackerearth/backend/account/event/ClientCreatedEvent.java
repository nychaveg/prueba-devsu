package com.devsu.hackerearth.backend.account.event;


import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class ClientCreatedEvent {
    private final Long clientId;
    private final boolean active;
}