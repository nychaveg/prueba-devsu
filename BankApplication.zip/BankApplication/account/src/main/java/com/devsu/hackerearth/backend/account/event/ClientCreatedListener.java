package com.devsu.hackerearth.backend.account.event;

import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.devsu.hackerearth.backend.account.model.ClienteRef;
import com.devsu.hackerearth.backend.account.repository.ClienteRefRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Component
@RequiredArgsConstructor
@Slf4j
public class ClientCreatedListener {

    private final ClienteRefRepository clienteRefRepository;

    @Async
    @EventListener
    public void onClientCreated(ClientCreatedEvent event) {

        log.info("Evento recibido en ACCOUNT: clientId={}", event.getClientId());

        ClienteRef ref = new ClienteRef();
        ref.setClientId(event.getClientId());
        ref.setActive(true);

        clienteRefRepository.save(ref);

        log.info("ClienteRef guardado en ACCOUNT: {}", event.getClientId());
    }
}