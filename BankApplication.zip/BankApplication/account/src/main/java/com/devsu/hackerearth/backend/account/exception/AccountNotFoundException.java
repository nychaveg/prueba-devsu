package com.devsu.hackerearth.backend.account.exception;

public class AccountNotFoundException extends BusinessException {
    private static final long serialVersionUID = 1L;

    public AccountNotFoundException(String message) {
        super(message);
    }
}