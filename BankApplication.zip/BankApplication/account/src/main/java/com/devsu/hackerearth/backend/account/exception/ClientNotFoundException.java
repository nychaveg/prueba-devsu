package com.devsu.hackerearth.backend.account.exception;

public class ClientNotFoundException extends BusinessException {
    private static final long serialVersionUID = 1L;

    public ClientNotFoundException(String message) {
        super(message);
    }
}