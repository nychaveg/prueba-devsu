package com.devsu.hackerearth.backend.account.model;

public class ClientCreatedMessage {
    private Long clientId;
    public Long getClientId() { return clientId; }
    public void setClientId(Long clientId) { this.clientId = clientId; }
}