package com.devsu.hackerearth.backend.account.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class ClienteRef {
    @Id
    private Long clientId;
    private boolean active;

}
