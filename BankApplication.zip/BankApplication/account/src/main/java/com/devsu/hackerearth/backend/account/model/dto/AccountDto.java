package com.devsu.hackerearth.backend.account.model.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class AccountDto {

	private Long id;
	private String number;

	@NotBlank(message = "Tipo de cuenta es obligatorio")
	private String type;

	@NotNull(message = "Saldo inicial obligatorio")
	@Positive(message = "El saldo inicial debe ser mayor a cero")
	private double initialAmount;

	private boolean isActive;
	private Long clientId;
}
