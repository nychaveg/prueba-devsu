package com.devsu.hackerearth.backend.account.service;

import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.dto.PartialAccountDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import com.devsu.hackerearth.backend.account.repository.ClienteRefRepository;

@Service
public class AccountServiceImpl implements AccountService {

    private final AccountRepository accountRepository;

    public AccountServiceImpl(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    @Override
    public List<AccountDto> getAll() {
        // Get all accounts
        return accountRepository.findAll().stream().map(this::mapToDto).collect(Collectors.toList());
    }

    @Override
    public AccountDto getById(Long id) {
        // Get accounts by id
        return accountRepository.findById(id).map(this::mapToDto).orElse(null);
    }

    @Override
    public AccountDto create(AccountDto accountDto) {
        Account account = accountRepository.save(mapToEntity(accountDto));
        return mapToDto(account);
    }

    @Override
    public AccountDto update(AccountDto accountDto) {
        // Update account
        if (!accountRepository.existsById(accountDto.getId())) {
            return null;
        }
        Account account = accountRepository.save(mapToEntity(accountDto));
        return mapToDto(account);
    }

    @Override
    public AccountDto partialUpdate(Long id, PartialAccountDto partialAccountDto) {
        // Partial update account
        return null;
    }

    @Override
    public void deleteById(Long id) {
        // Delete account
        if (accountRepository.existsById(id)) {
            accountRepository.deleteById(id);
        }
    }

    private AccountDto mapToDto(Account account) {
        return new AccountDto(
                account.getId(),
                account.getNumber(),
                account.getType(),
                account.getInitialAmount(),
                account.isActive(),
                account.getClientId());
    }

    private Account mapToEntity(AccountDto dto) {
        Account account = new Account();
        account.setId(dto.getId());
        account.setNumber(dto.getNumber());
        account.setType(dto.getType());
        account.setInitialAmount(dto.getInitialAmount());
        account.setActive(dto.isActive());
        account.setClientId(dto.getClientId());
        return account;
    }

}
