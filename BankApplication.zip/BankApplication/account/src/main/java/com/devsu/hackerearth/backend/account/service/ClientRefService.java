package com.devsu.hackerearth.backend.account.service;

import java.util.List;

import com.devsu.hackerearth.backend.account.model.dto.ClientRefDto;

public interface ClientRefService {

    public List<ClientRefDto> getAll();
    void create(ClientRefDto dto);
    boolean existsById(Long clientId);



}