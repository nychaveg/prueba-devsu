package com.devsu.hackerearth.backend.account.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.account.model.ClienteRef;
import com.devsu.hackerearth.backend.account.model.dto.ClientRefDto;
import com.devsu.hackerearth.backend.account.repository.ClienteRefRepository;

@Service
public class ClientRefServiceImpl implements ClientRefService {
    private final ClienteRefRepository clienteRefRepository;

    public ClientRefServiceImpl(ClienteRefRepository clienteRefRepository) {
        this.clienteRefRepository = clienteRefRepository;
    }

    @Override
    public List<ClientRefDto> getAll() {
        // Get all accounts
        return clienteRefRepository.findAll().stream().map(this::mapToDto).collect(Collectors.toList());
    }

    private ClientRefDto mapToDto(ClienteRef clienteRef) {
        return new ClientRefDto(
                clienteRef.getClientId(), true);
    }

    @Override
    public void create(ClientRefDto dto) {
        ClienteRef ref = new ClienteRef();
        ref.setClientId(dto.getClientId());
        ref.setActive(true);
        clienteRefRepository.save(ref);
    }

    @Override
    public boolean existsById(Long clientId) {
        return clienteRefRepository.existsById(clientId);
    }

}
