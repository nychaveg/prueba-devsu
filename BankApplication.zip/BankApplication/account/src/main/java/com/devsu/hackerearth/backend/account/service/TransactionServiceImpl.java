package com.devsu.hackerearth.backend.account.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.account.exception.AccountNotFoundException;
import com.devsu.hackerearth.backend.account.exception.BusinessException;
import com.devsu.hackerearth.backend.account.exception.InsufficientBalanceException;
import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import com.devsu.hackerearth.backend.account.repository.TransactionRepository;

import java.lang.RuntimeException;

@Service
public class TransactionServiceImpl implements TransactionService {

    private final TransactionRepository transactionRepository;
    private final AccountRepository accountRepository;

    public TransactionServiceImpl(TransactionRepository transactionRepository, AccountRepository accountRepository) {
        this.transactionRepository = transactionRepository;
        this.accountRepository = accountRepository;
    }

    @Override
    public List<TransactionDto> getAll() {
        // Get all transactions
        return transactionRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    public TransactionDto getById(Long id) {
        Optional<Transaction> transaction = transactionRepository.findById(id);

        return transaction.map(this::toDto).orElse(null);
    }

    @Override
    public TransactionDto create(TransactionDto transactionDto) {
        // Create transaction

        Account account = accountRepository.findById(transactionDto.getAccountId())
                .orElseThrow(() -> new AccountNotFoundException(
                        "Cuenta no encontrada con id: " + transactionDto.getAccountId()));

        double currentBalance = account.getInitialAmount();
        double amount = transactionDto.getAmount();

        if (amount == 0) {
            throw new RuntimeException("El mongo del movimiento no puede ser cero");
        }

        if (transactionDto.getType().equalsIgnoreCase("RETIRO")) {
            amount = -Math.abs(amount);
        } else if (transactionDto.getType().equalsIgnoreCase("DEPOSITO")) {
            amount = Math.abs(amount);
        }

        if (amount == 0) {
            throw new BusinessException("El monto del movimiento no puede ser cero");
        }

        double newBalance = currentBalance + amount;

        if (newBalance < 0) {
            throw new InsufficientBalanceException("Saldo insuficiente para realizar el movimiento");
        }

        account.setInitialAmount(newBalance);
        accountRepository.save(account);

        Transaction transaction = new Transaction();
        transaction.setDate(transactionDto.getDate() != null ? transactionDto.getDate() : new Date());
        transaction.setType(transactionDto.getType());
        transaction.setAmount(amount);
        transaction.setBalance(newBalance);
        transaction.setAccountId(transactionDto.getAccountId());

        return toDto(transactionRepository.save(transaction));
    }

    @Override
    public List<BankStatementDto> getAllByAccountClientIdAndDateBetween(Long clientId, Date dateTransactionStart,
            Date dateTransactionEnd) {

        List<Account> accounts = accountRepository.findByClientId(clientId);
        if (accounts.isEmpty()) {
            throw new AccountNotFoundException("No se encontraron cuentas para el cliente con id: " + clientId);
        }

        return accounts.stream()
                .flatMap(account -> {

                    List<Transaction> transactions = transactionRepository
                            .findByAccountIdAndDateBetween(account.getId(), dateTransactionStart, dateTransactionEnd);

                    return transactions.stream().map(tx -> new BankStatementDto(
                            tx.getDate(),
                            account.getClientId().toString(),
                            account.getNumber(),
                            account.getType(),
                            account.getInitialAmount(),
                            account.isActive(),
                            tx.getType(),
                            tx.getAmount(),
                            tx.getBalance()));

                }).collect(Collectors.toList());

    }

    @Override
    public TransactionDto getLastByAccountId(Long accountId) {
        // If you need it
        return null;
    }

    private TransactionDto toDto(Transaction transaction) {
        return new TransactionDto(
                transaction.getId(),
                transaction.getDate(),
                transaction.getType(),
                transaction.getAmount(),
                transaction.getBalance(),
                transaction.getAccountId());
    }

}
