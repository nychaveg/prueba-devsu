package com.devsu.hackerearth.backend.account;

import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.*;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class AccountIntegrationTest {

    @Autowired
    private TestRestTemplate restTemplate;

    @Autowired
    private AccountRepository accountRepository;

    @Test
    @DisplayName("Flujo completo de integración: crear, obtener y validar cuenta")
    void flujoCompletoAccount() {
        // Crear DTO
        AccountDto newAccount = new AccountDto(null, "12345", "savings", 100.0, true, 1L);

        ResponseEntity<AccountDto> postResponse = restTemplate.postForEntity(
                "/api/accounts", newAccount, AccountDto.class);

        assertThat(postResponse.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        assertThat(postResponse.getBody()).isNotNull();
        assertThat(postResponse.getBody().getNumber()).isEqualTo("12345");

        Long accountId = postResponse.getBody().getId();

        ResponseEntity<AccountDto> getResponse = restTemplate.getForEntity(
                "/api/accounts/" + accountId, AccountDto.class);

        assertThat(getResponse.getStatusCode()).isEqualTo(HttpStatus.OK);
        AccountDto accountObtenida = getResponse.getBody();
        assertThat(accountObtenida).isNotNull();
        assertThat(accountObtenida.getNumber()).isEqualTo("12345");

        Account accountDB = accountRepository.findById(accountId).orElse(null);
        assertThat(accountDB).isNotNull();
        assertThat(accountDB.getNumber()).isEqualTo("12345");
        assertThat(accountDB.getInitialAmount()).isEqualTo(100.0);
    }
}
