package com.devsu.hackerearth.backend.client.config;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import com.devsu.hackerearth.backend.client.model.dto.ClientCreatedDto;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Component
@RequiredArgsConstructor
@Slf4j
public class AsyncClientRefSender {

    private final WebClient.Builder webClient;

    @Async
    public void sendClientCreated(ClientCreatedDto dto) {
        log.info("Enviando clientRef async a ACCOUNT {}", dto);

        webClient.build()
                .post()
                .uri("http://localhost:8002/api/client-ref")
                .bodyValue(dto)
                .retrieve()
                .bodyToMono(Void.class)
                .subscribe(
                        ok -> log.info("ClientRef creado OK"),
                        err -> log.error("Error enviando clientRef", err));
    }
}