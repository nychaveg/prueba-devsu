package com.devsu.hackerearth.backend.client.event;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class ClientCreatedEvent {
    private final Long clientId;


}
