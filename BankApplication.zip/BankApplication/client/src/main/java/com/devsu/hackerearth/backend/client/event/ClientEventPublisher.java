package com.devsu.hackerearth.backend.client.event;

import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;

import com.devsu.hackerearth.backend.client.model.dto.ClientCreatedDto;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class ClientEventPublisher {

    private final ApplicationEventPublisher publisher;

    public void publishClientCreated(ClientCreatedDto dto) {
        publisher.publishEvent(dto);
    }

    public void publishClientUpdated(ClientCreatedDto dto) {
        publisher.publishEvent(dto);
    }
}