package com.devsu.hackerearth.backend.client.mapper;

import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@Builder
public class ClientMapper {
    public static ClientDto toDto(Client c) {
        if (c == null) return null;
        return ClientDto.builder()
                .id(c.getId())
                .dni(c.getDni())
                .name(c.getName())
                .password(c.getPassword())
                .gender(c.getGender())
                .age(c.getAge())
                .address(c.getAddress())
                .phone(c.getPhone())
                .isActive(c.isActive())
                .build();
    }

    public static Client toEntity(ClientDto d) {
        if (d == null) return null;
        Client c = new Client();
        c.setId(d.getId());
        c.setDni(d.getDni());
        c.setName(d.getName());
        c.setPassword(d.getPassword());
        c.setGender(d.getGender());
        c.setAge(d.getAge());
        c.setAddress(d.getAddress());
        c.setPhone(d.getPhone());
        c.setActive(d.isActive());
        return c;
    }
}
