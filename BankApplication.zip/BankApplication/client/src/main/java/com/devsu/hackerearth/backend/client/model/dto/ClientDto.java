package com.devsu.hackerearth.backend.client.model.dto;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@AllArgsConstructor
@Builder
public class ClientDto {

	private Long id;

	@NotBlank(message = "La identificación es obligatoria")
	@Size(min = 10, max = 10, message = "La identificación debe tener exactamente 10 caracteres")
	private String dni;

	@NotBlank(message = "El nombre es obligatorio")
	@Size(max = 100, message = "El nombre no debe superar los 100 caracteres")
	private String name;

	@NotBlank(message = "La contraseña es obligatoria")
	private String password;

	@NotBlank(message = "El género es obligatorio")
	@Pattern(regexp = "^[MF]$", message = "El género debe ser 'M' o 'F'")
	private String gender;

	@NotNull(message = "La edad es obligatoria")
	@Min(value = 18, message = "La edad mínima permitida es 18 años")
	@Max(value = 100, message = "La edad máxima permitida es 100 años")
	private int age;

	@NotBlank(message = "La dirección es obligatoria")
	@Size(max = 200, message = "La dirección no debe superar los 200 caracteres")
	private String address;

	@NotBlank(message = "El teléfono es obligatorio")
	@Pattern(regexp = "^[0-9]{7,15}$", message = "El teléfono debe contener entre 7 y 15 dígitos")
	private String phone;

	@NotNull(message = "El estado es obligatorio")
	private boolean isActive;
}
