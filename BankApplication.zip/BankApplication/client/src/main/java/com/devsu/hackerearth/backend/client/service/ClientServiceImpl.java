package com.devsu.hackerearth.backend.client.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.devsu.hackerearth.backend.client.config.AsyncClientRefSender;
import com.devsu.hackerearth.backend.client.event.ClientEventPublisher;
import com.devsu.hackerearth.backend.client.mapper.ClientMapper;
import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientCreatedDto;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.dto.PartialClientDto;
import com.devsu.hackerearth.backend.client.repository.ClientRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class ClientServiceImpl implements ClientService {

	private final ClientRepository clientRepository;
	// private final ClientEventPublisher eventPublisher;
	private final AsyncClientRefSender asyncSender;

	@Override
	@Transactional
	public ClientDto create(ClientDto dto) {

		Client client = ClientMapper.toEntity(dto);
		client.setActive(true);

		Client saved = clientRepository.save(client);

		// Publicar evento
		ClientCreatedDto event = new ClientCreatedDto(saved.getId(), true);
		// eventPublisher.publishClientCreated(event);

		asyncSender.sendClientCreated(event);

		return ClientMapper.toDto(saved);
	}

	@Override
	public ClientDto update(ClientDto clientDto) {
		// Update client
		Optional<Client> exists = clientRepository.findById(clientDto.getId());

		if (exists.isPresent()) {
			Client cliente = exists.get();
			cliente.setDni(clientDto.getDni());
			cliente.setName(clientDto.getName());
			cliente.setPassword(clientDto.getPassword());
			cliente.setGender(clientDto.getGender());
			cliente.setAge(clientDto.getAge());
			cliente.setAddress(clientDto.getAddress());
			cliente.setPhone(clientDto.getPhone());
			cliente.setActive(clientDto.isActive());

			Client update = clientRepository.save(cliente);
			return toDto(update);
		}

		return null;
	}

	@Override
	public List<ClientDto> getAll() {
		// Get all clients
		List<Client> clients = clientRepository.findAll();

		return clients.stream().map(this::toDto)
				.collect(Collectors.toList());
	}

	@Override
	public ClientDto getById(Long id) {
		// Get clients by id
		Optional<Client> client = clientRepository.findById(id);
		return client.map(this::toDto).orElse(null);
	}

	@Override
	public ClientDto partialUpdate(Long id, PartialClientDto partialClientDto) {
		// Partial update account
		return null;
	}

	@Override
	public void deleteById(Long id) {
		clientRepository.deleteById(id);
	}

	private ClientDto toDto(Client client) {

		if (client == null) {
			return null;
		}
		return new ClientDto(client.getId(),
				client.getDni(),
				client.getName(),
				client.getPassword(),
				client.getGender(),
				client.getAge(),
				client.getAddress(),
				client.getPhone(),
				client.isActive());
	}
}