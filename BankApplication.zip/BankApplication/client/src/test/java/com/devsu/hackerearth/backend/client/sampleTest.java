package com.devsu.hackerearth.backend.client;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.devsu.hackerearth.backend.client.controller.ClientController;
import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.service.ClientService;

@SpringBootTest
public class sampleTest {

    private ClientService clientService = mock(ClientService.class);
    private ClientController clientController = new ClientController(clientService);

    @Test
    void createClientTest() {
        // Arrange
        ClientDto newClient = new ClientDto(1L, "Dni", "Name", "Password", "Gender", 1, "Address", "9999999999", true);
        ClientDto createdClient = new ClientDto(1L, "Dni", "Name", "Password", "Gender", 1, "Address", "9999999999",
                true);
        when(clientService.create(newClient)).thenReturn(createdClient);

        // Act
        ResponseEntity<ClientDto> response = clientController.create(newClient);

        // Assert
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(createdClient, response.getBody());
    }

    @Test
    void clientEntityTest() {
        Client client = new Client();
        client.setId(1L);
        client.setDni("1234567890");
        client.setName("Test Name");
        client.setPassword("secret");
        client.setGender("M");
        client.setAge(30);
        client.setAddress("Test Address");
        client.setPhone("9999999999");
        client.setActive(true);

        assertEquals(1L, client.getId());
        assertEquals("1234567890", client.getDni());
        assertEquals("Test Name", client.getName());
        assertEquals("secret", client.getPassword());
        assertEquals("M", client.getGender());
        assertEquals(30, client.getAge());
        assertEquals("Test Address", client.getAddress());
        assertEquals("9999999999", client.getPhone());
        assertEquals(true, client.isActive());
    }
}
